@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')

<h1>Panel de Control</h1>

@stop

@section('content')

    <p>Bienvenido al panel de administración del Catálogo de Consulta de Tesis y Tesinas de la Universidad de Aconcagua Sede Ancud</p>

@stop

@section('css')

<link rel="stylesheet" href="/css/admin_custom.css">

@stop