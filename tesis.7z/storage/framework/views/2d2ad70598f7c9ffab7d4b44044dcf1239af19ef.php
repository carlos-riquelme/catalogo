<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>

<h1>Panel de Control</h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <p>Bienvenido al panel de administración del Catálogo de Consulta de Tesis y Tesinas de la Universidad de Aconcagua Sede Ancud</p>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<link rel="stylesheet" href="/css/admin_custom.css">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>