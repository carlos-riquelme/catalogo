<?php $__env->startSection('title', 'Dashboard'); ?>


<?php $__env->startSection('content'); ?>

<h1>Creación de Usuarios del Sistema</h1>

<?php echo Form::open(['method'=>'POST', 'action'=> 'AdminUsersController@store','files'=>true]); ?>


<div class="col-sm-6" >

<div class="form-group" >
    
    <?php echo Form::label('name', 'Nombre:'); ?>

    <?php echo Form::text('name', null, ['class'=> 'form-control']); ?>

            
</div>

<div class="form-group">
    
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::email('email', null, ['class'=> 'form-control']); ?>

    
    
</div>
 <div class="form-group">
    
    <?php echo Form::label('role_id', 'Rol:'); ?>

    <?php echo Form::select('role_id', ['' => 'Escoger'] + $roles, null, ['class'=> 'form-control']); ?>

    
    
</div>
<div class="form-group">
    <?php echo Form::label('is_active', 'Estado:'); ?>

    <?php echo Form::select('is_active', array(1 => 'Activo', 0=> 'Inactivo'), 0 , ['class'=> 'form-control']); ?>

</div>


<div class="form-group">
    <?php echo Form::label('password', 'Contraseña:'); ?>

    <?php echo Form::password('password', ['class'=> 'form-control']); ?>

</div>

<div class="form-group">

    
    <?php echo Form::submit('Create User', ['class'=> 'btn btn-primary']); ?>

    
</div>


<?php echo Form::close(); ?>


<?php echo $__env->make('includes.form_error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>